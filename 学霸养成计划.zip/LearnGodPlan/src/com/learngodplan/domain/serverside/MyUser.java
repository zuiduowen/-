package com.learngodplan.domain.serverside;

import cn.bmob.v3.BmobUser;

@SuppressWarnings("serial")
public class MyUser extends BmobUser {
	//BmobUser中已有username password字段，故无需定义，可以在此添加与后台数据库用户表不冲突的
	//扩展字段
}
