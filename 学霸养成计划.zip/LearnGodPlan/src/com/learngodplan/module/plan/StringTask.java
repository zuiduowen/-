package com.learngodplan.module.plan;

public class StringTask {
    public String tName;
    public String tPriority;
    public String tStartTime;
    public String tEndTime;
    public String tPlanTime;
    public String tTotalTime;
    //0为未，1为已
    public String isFinished;
    
    public StringTask(){}
}
